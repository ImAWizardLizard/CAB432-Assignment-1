self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d52adf68cec4b4b72a228cc40bb2cb42",
    "url": "/index.html"
  },
  {
    "revision": "81b7e90c90d8e75fac53",
    "url": "/static/css/2.878b4ebd.chunk.css"
  },
  {
    "revision": "81b7e90c90d8e75fac53",
    "url": "/static/js/2.ccfffcfb.chunk.js"
  },
  {
    "revision": "d54dc42d7a851958235835d024e960bb",
    "url": "/static/js/2.ccfffcfb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ecf84eaf420d10bc52ce",
    "url": "/static/js/main.fae32949.chunk.js"
  },
  {
    "revision": "2747b914e9a60db2276f",
    "url": "/static/js/runtime-main.c8a21426.js"
  }
]);